# Welcome to your Python project!
class Node:
    """A node for our Doubly Linked List."""
    def __init__(self, key: int = 0, value: int = 0):
        self.key = key
        self.value = value
        self.prev = None
        self.next = None

class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {}  # Maps key -> Node
        
        # Initialize dummy head and tail nodes to simplify edge cases
        self.head = Node()
        self.tail = Node()
        self.head.next = self.tail
        self.tail.prev = self.head

    def _remove_node(self, node: Node):
        """Removes a specific node from the linked list."""
        previous_node = node.prev
        next_node = node.next
        previous_node.next = next_node
        next_node.prev = previous_node

    def _add_to_head(self, node: Node):
        """Inserts a node right after the dummy head (Most Recently Used)."""
        node.next = self.head.next
        node.prev = self.head
        self.head.next.prev = node
        self.head.next = node

    def get(self, key: int) -> int:
        if key in self.cache:
            node = self.cache[key]
            # Since it's accessed, move it to the front
            self._remove_node(node)
            self._add_to_head(node)
            return node.value
        return -1

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            # Key exists: update its value and move it to the front
            node = self.cache[key]
            node.value = value
            self._remove_node(node)
            self._add_to_head(node)
        else:
            # New key: check if cache is full
            if len(self.cache) >= self.capacity:
                # Evict the least recently used node (just before dummy tail)
                lru_node = self.tail.prev
                self._remove_node(lru_node)
                del self.cache[lru_node.key]  # Remove from hash map
            
            # Create and add the new node
            new_node = Node(key, value)
            self._add_to_head(new_node)
            self.cache[key] = new_node