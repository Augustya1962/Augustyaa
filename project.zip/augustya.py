def can_attend_all(events: list[tuple[int, int]]) -> bool:
    """
    Determines if a person can attend all events without any overlaps.
    """
    # Step 1: Sort events based on their start times
    events.sort(key=lambda x: x)
    
    # Step 2: Check for any overlapping intervals
    for i in range(len(events) - 1):
        current_event_end = events[i]
        next_event_start = events[i+1]
        
        # If the next meeting starts strictly before the current one finishes, there's a clash
        if next_event_start < current_event_end:
            return False
            
    return True


def min_rooms_required(events: list[tuple[int, int]]) -> int:
    """
    Calculates the minimum number of meeting rooms required to schedule all events.
    """
    if not events:
        return 0
        
    # Step 1: Extract and independently sort start and end times chronologically
    start_times = sorted([e for e in events])
    end_times = sorted([e for e in events])
    
    start_ptr, end_ptr = 0, 0
    current_rooms = 0
    max_rooms = 0
    
    # Step 2: Walk through the timeline using two pointers
    while start_ptr < len(events):
        # If a meeting starts before the earliest active meeting ends, allocate a new room
        if start_times[start_ptr] < end_times[end_ptr]:
            current_rooms += 1
            start_ptr += 1
        else:
            # A meeting ended (or seamlessly transitioned at adjacent times e.g. 10 == 10), freeing a room
            current_rooms -= 1
            end_ptr += 1
            
        # Record the highest number of concurrent rooms used at any peak point
        max_rooms = max(max_rooms, current_rooms)
        
    return max_rooms


# --- TEST DRIVER TO VERIFY CODES ---
if __name__ == "__main__":
    print("Testing Event Scheduler...")
    
    # Test Case 1: Seamless consecutive meetings (No overlaps)
    # Timeline: 9->10, 10->11, 11->12
    meetings_1 = [(9, 10), (10, 11), (11, 12)]
    print("\n--- Test Case 1 ---")
    print(f"Meetings: {meetings_1}")
    print(f"Can attend all? (Expected True): {can_attend_all(meetings_1)}")
    print(f"Min rooms required (Expected 1): {min_rooms_required(meetings_1)}")
    
    # Test Case 2: Heavy overlapping meetings
    # Timeline: (9, 11) and (10, 12) overlap between 10:00 and 11:00
    meetings_2 = [(9, 11), (10, 12), (11, 13)]
    print("\n--- Test Case 2 ---")
    print(f"Meetings: {meetings_2}")
    print(f"Can attend all? (Expected False): {can_attend_all(meetings_2)}")
    print(f"Min rooms required (Expected 2): {min_rooms_required(meetings_2)}")
    
    # Test Case 3: Multiple overlapping meetings at the exact same peak time
    meetings_3 = [(9, 10), (9, 12), (10, 13), (9, 11)]
    print("\n--- Test Case 3 ---")
    print(f"Meetings: {meetings_3}")
    print(f"Min rooms required (Expected 3): {min_rooms_required(meetings_3)}")
    
    print("\nAll scheduler tests passed smoothly!")